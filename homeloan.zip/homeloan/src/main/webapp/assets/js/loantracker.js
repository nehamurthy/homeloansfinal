/**
 * JS for progress bar
 */

function checkProgress(status) {
	
	alert(status);
	if(status === "NV")
		alert(status);
}