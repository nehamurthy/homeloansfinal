package homeloan.dao;


import homeloan.model.LoanAccount;

public interface AccountDaoIntf {
	
	public LoanAccount trackAccount(int accno);

}
