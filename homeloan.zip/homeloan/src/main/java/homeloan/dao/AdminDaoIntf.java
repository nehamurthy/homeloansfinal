package homeloan.dao;

import java.util.List;

import homeloan.model.Admin;
import homeloan.model.ApplicationStatus;

public interface AdminDaoIntf {

	public boolean adminLogin(Admin admin);
	public List<Object[]> viewPendingApprovals1();
	public List<Object[]> viewForm(String applicationid);
	public boolean changeStatusToVerified(String applicationid);
}
