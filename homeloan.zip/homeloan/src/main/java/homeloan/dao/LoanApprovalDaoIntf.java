package homeloan.dao;

import java.util.List;

public interface LoanApprovalDaoIntf {

	public List<Object[]> approveLoan(String applicationid);
	public boolean changeStatusToApproved(String applicationid);
}
