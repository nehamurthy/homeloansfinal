package homeloan.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import homeloan.model.ApplicationStatus;
import homeloan.model.LoanAccount;

@Repository("loanApprovalDao")
public class LoanApprovalDaoImpl implements LoanApprovalDaoIntf {

	@PersistenceContext
	EntityManager em;
	
	public List<Object[]> approveLoan(String applicationid) {
		
		Query query = em.createNativeQuery("select a.gender, l.loanamount, l.tenure, l.downpayment, p.propertylocation, p.amount,i.dtype, i.monthlysalary, i.retirementage, i.organization, i.turnover, i.natureofbusiness, i.businessvintage from users u , applicants a , loan l,  property p , AbstractUser i, applicationstatus a1 where u.userid=a.userid  and l.userid=u.userid and p.userid=u.userid and u.userid=a1.userid and (i.userid=u.userid) and a1.applicationid=:appid").setParameter("appid", applicationid);
		
		@SuppressWarnings("unchecked")
		List<Object[]> ulist = query.getResultList();
		return ulist;
	}

	public boolean changeStatusToApproved(String applicationid) {
		
		boolean flag = false;
		ApplicationStatus applicationStatus = em.find(ApplicationStatus.class, applicationid);
		Query query = em.createNativeQuery("update applicationstatus set status='A' where applicationid=:appid").setParameter("appid", applicationStatus.getApplicationid());
		//em.joinTransaction();
		int result = query.executeUpdate();
		if(result > 0) {
			
			flag = true;
		}
		else
			flag = false;
	
		return flag;
	}
}
