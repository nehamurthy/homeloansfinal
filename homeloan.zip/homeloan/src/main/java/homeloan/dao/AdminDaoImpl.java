package homeloan.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import homeloan.model.Admin;
import homeloan.model.ApplicationStatus;

@Repository("adminDao")
public class AdminDaoImpl implements AdminDaoIntf {

	@PersistenceContext
	EntityManager em;
	
	public boolean adminLogin(Admin admin) {
		
		boolean flag = false;
		
		Admin a = null;
		 try {
			   
				String username =  admin.getUsername();
				String password = admin.getPassword();
				
				a = (Admin)em.createQuery("select a from Admin a where a.username=:username").setParameter("username", username).getSingleResult();
				
				if(( a.getUsername().equals(username) ) && ( a.getPassword().equals(password) ) ) {
					
					flag = true;
				}
				else flag = false;
			
		    }
		    catch(Exception e) { 
		    	System.out.println("Error:"+e);
		    }
		return flag;
	}

	public List<Object[]> viewPendingApprovals1() {
		
		Query query = em.createNativeQuery("select a.applicationid, u.firstname from applicationstatus a join users u on a.userid = u.userid where a.status='NV' or a.status='V'");
		/*Query query = em.createNativeQuery("select a.applicationid, a.applicationstatus from applicationstatus a where a.applicationstatus='NV'");*/
		@SuppressWarnings("unchecked")
		List<Object[]> list = query.getResultList();
		return list;
	}

	public List<Object[]> viewForm(String applicationid) {
		
		Query query = em.createNativeQuery("select u.firstname, u.lastname, a.dob, a.gender, a.aadharno, a.panno, l.loanamount, l.tenure, l.downpayment, p.propertylocation, p.amount,i.dtype, i.monthlysalary, i.turnover from users u , applicants a , loan l,  property p , AbstractUser i, applicationstatus a1 where  u.userid=a.userid  and l.userid=u.userid and p.userid=u.userid and u.userid=a1.userid and ( i.userid=u.userid) and a1.applicationid=:appid").setParameter("appid", applicationid);
		
		
		/*Query query = em.createNativeQuery("select a.applicationid, a.applicationstatus from applicationstatus a where a.applicationstatus='NV'");*/
		
		
		@SuppressWarnings("unchecked")
		List<Object[]> alist = query.getResultList();
		return alist;
	}

	public boolean changeStatusToVerified(String applicationid) {
		
		boolean flag = false;
		ApplicationStatus applicationStatus = em.find(ApplicationStatus.class, applicationid);
		Query query = em.createNativeQuery("update applicationstatus set status='V' where applicationid=:appid").setParameter("appid", applicationStatus.getApplicationid());
		//em.joinTransaction();
		int result = query.executeUpdate();
		if(result > 0) {
			
			flag = true;
		}
		else
			flag = false;
	
		return flag;
	}
	
	

	
}
