package homeloan.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import homeloan.service.LoanApprovalServiceIntf;

@Controller("loanApprovalController")
public class LoanApprovalController {
	
	@Autowired
	public LoanApprovalServiceIntf loanApprovalServiceIntf;
	
	@RequestMapping(value="/approve", method=RequestMethod.GET)
	public ModelAndView approveLoan(HttpServletRequest request, HttpServletResponse response) {
		
		String applicationid = request.getParameter("appid");
		@SuppressWarnings("unchecked")
		List<Object> loanlist = loanApprovalServiceIntf.approveLoan(applicationid);
		ModelAndView mav = new ModelAndView("loaninfo");
		mav.addObject("appid", applicationid);
		mav.addObject("loanlist", loanlist);
		return mav;
	}
	
	@RequestMapping(value="/finalapproval", method=RequestMethod.GET)
	public ModelAndView finalApproval(HttpServletRequest request, HttpServletResponse response) {
		
		String applicationid = request.getParameter("appid");
		boolean flag = loanApprovalServiceIntf.changeStatusToApproved(applicationid);
		ModelAndView mav = null;
		if(flag) {
			
			String msg = "User with Application ID "+applicationid+" is approved";
			mav = new ModelAndView("loaninfo");
			mav.addObject("message",msg);
		}
		return mav;
	}
}
