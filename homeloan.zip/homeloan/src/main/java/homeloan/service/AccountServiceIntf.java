package homeloan.service;

import homeloan.model.LoanAccount;

public interface AccountServiceIntf {
	
	 public LoanAccount trackAccount(int accno);
	

}
