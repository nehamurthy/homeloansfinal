package homeloan.service;

import java.util.List;

import homeloan.model.Admin;
import homeloan.model.ApplicationStatus;

public interface AdminServiceIntf {

	public boolean adminLogin(Admin admin);
	public List<Object[]> viewPendingApprovals1();
	public List<Object[]> viewForm(String applicationid);
	public boolean changeStatusToVerified(String applicationid);
	
}
