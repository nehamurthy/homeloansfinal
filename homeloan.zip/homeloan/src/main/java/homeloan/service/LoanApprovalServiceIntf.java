package homeloan.service;

import java.util.List;

public interface LoanApprovalServiceIntf {

	public List<Object> approveLoan(String applicationid);
	public boolean changeStatusToApproved(String applicationid);
}
