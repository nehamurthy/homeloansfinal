/*
 * The code contains the business logic to approve a loan based on user input.
 * The users' data like income, retirement age, turnover, etc. will be used to estimate the loan amount that is grantable to them.
 */

package homeloan.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import homeloan.dao.LoanApprovalDaoIntf;

@Service("loanApprovalService")
public class LoanApprovalServiceImpl implements LoanApprovalServiceIntf {

	@Autowired
	public LoanApprovalDaoIntf loanApprovalDaoIntf;
	
	@Transactional
	public List<Object> approveLoan(String applicationid) {
		
		double msal = 0;
		double loanamount = 0; 
		double principal = 0;
		int tenure = 0;
		double loanamount1 = 0;
		double principal1 = 0;
		int tenure1 = 0;
		double interest = 8.5;
		double x = 0;
		double emi = 0;
		double x1 = 0;
		double emi1 = 0;
		 List<Object> applist = null;
		
		List<Object[]> alist = loanApprovalDaoIntf.approveLoan(applicationid);
		/*for (Object[] objects : alist) {
			
			System.out.println(objects);
		}*/
		
		for (Object[] aa: alist) {
			/*for(Object x: aa){
				System.out.print(x+" ");
			}*/
			
			for(int i=0;i<aa.length;i++) {
				
				System.out.println(aa[i]);
				if(aa[6].toString().equals("salaried")) {
					
					loanamount = Double.parseDouble(aa[7].toString()) * 60 * 0.6;
					principal = Double.parseDouble(aa[1].toString());
					tenure = Integer.parseInt(aa[2].toString()) * 12;
					//interest = 8.5;
					
					x = Math.pow(1 + interest, tenure);
				    emi = (principal*x*interest)/(x-1);
				    applist = new ArrayList<Object>();
					applist.add(loanamount);
					applist.add(emi);
				}
				
				else if(aa[6].toString().equals("selfemployed")) {
					
					msal = Double.parseDouble(aa[10].toString()) / 12;
					loanamount1 = msal * 60 * 0.6;
					principal1 = Double.parseDouble(aa[1].toString());
					tenure1 = Integer.parseInt(aa[2].toString()) * 12;
					//interest = 8.5;
					
					x1 = Math.pow(1 + interest, tenure1);
				    emi1 = (principal1*x1*interest)/(x1-1);
				    
				    applist = new ArrayList<Object>();
					applist.add(loanamount1);
					applist.add(emi1);
				}
			}
			System.out.println("\n"+applist.get(0)+" "+applist.get(1));
			
		}
		//System.out.println(loanamount);
		
		
		return applist;
		
	}

	
	@Transactional
	public boolean changeStatusToApproved(String applicationid) {
		
		return loanApprovalDaoIntf.changeStatusToApproved(applicationid);
	}
	
}
